# =============================================================================
# PROYEK AKHIR - PROBABILITAS DAN STATISTIKA
# Analisis Data Pembangunan Wilayah Indonesia
# =============================================================================
# Deskripsi : Skrip lengkap untuk analisis statistik dataset pembangunan
#             wilayah Indonesia (2020-2024).
# Dataset   : pembangunan_wilayah_missing_outlier.csv
# Tools     : R (ggplot2, dplyr, corrplot, nortest)
# =============================================================================

# ---- 0. Persiapan Library ----
# Install package jika belum tersedia
packages <- c("ggplot2", "dplyr", "corrplot", "nortest", "reshape2", "moments")
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, repos = "https://cran.r-project.org")
    library(pkg, character.only = TRUE)
  }
}


# ---- 1. MEMAHAMI DATASET ----

# 1.1 Baca dataset
data <- read.csv("../dataset/pembangunan_wilayah_missing_outlier.csv",
                 stringsAsFactors = FALSE)

# 1.2 Eksplorasi awal
cat("===== STRUKTUR DATA =====\n")
str(data)

cat("\n===== 6 BARIS PERTAMA =====\n")
head(data)

cat("\n===== DIMENSI DATA =====\n")
cat("Jumlah observasi:", nrow(data), "\n")
cat("Jumlah variabel :", ncol(data), "\n")

cat("\n===== RINGKASAN DATA =====\n")
summary(data)


# ---- 2. STATISTIKA DESKRIPTIF ----

cat("\n===== STATISTIKA DESKRIPTIF =====\n")

# Variabel numerik yang dianalisis
numerik <- c("pdrb_perkapita", "kemiskinan", "pengangguran", "ipm",
             "harapan_hidup", "rata_lama_sekolah", "akses_internet",
             "jalan_baik", "air_bersih")

for (var in numerik) {
  x <- data[[var]]
  x_clean <- x[!is.na(x)]
  cat("\n--", toupper(var), "--\n")
  cat("  N       :", length(x_clean), "\n")
  cat("  Mean    :", round(mean(x_clean), 4), "\n")
  cat("  Median  :", round(median(x_clean), 4), "\n")
  cat("  Std Dev :", round(sd(x_clean), 4), "\n")
  cat("  Varians :", round(var(x_clean), 4), "\n")
  cat("  Min     :", round(min(x_clean), 4), "\n")
  cat("  Max     :", round(max(x_clean), 4), "\n")
  cat("  Q1      :", round(quantile(x_clean, 0.25), 4), "\n")
  cat("  Q3      :", round(quantile(x_clean, 0.75), 4), "\n")
}


# ---- 3. ANALISIS MISSING VALUE ----

cat("\n===== MISSING VALUE PER VARIABEL =====\n")
mv_count <- colSums(is.na(data))
mv_pct   <- round(mv_count / nrow(data) * 100, 2)
mv_df    <- data.frame(Variabel = names(mv_count),
                       Jumlah_NA = mv_count,
                       Persen_NA = mv_pct,
                       row.names = NULL)
print(mv_df[mv_df$Jumlah_NA > 0, ])

cat("\nTotal missing value:", sum(mv_count), "\n")

# Penanganan: Median Imputation (robust terhadap outlier)
cat("\nMetode penanganan: MEDIAN IMPUTATION\n")

data_clean <- data  # copy sebelum imputasi

for (var in c("pdrb_perkapita", "kemiskinan", "pengangguran",
              "ipm", "akses_internet", "jalan_baik")) {
  med <- median(data_clean[[var]], na.rm = TRUE)
  na_idx <- is.na(data_clean[[var]])
  data_clean[[var]][na_idx] <- med
  cat("  Imputasi", var, ":", sum(na_idx), "baris dengan median =",
      round(med, 4), "\n")
}

cat("\nVerifikasi setelah imputasi:\n")
cat("Missing value tersisa:", sum(is.na(data_clean[, numerik])), "\n")


# ---- 4. ANALISIS OUTLIER ----

cat("\n===== ANALISIS OUTLIER (METODE IQR) =====\n")

for (var in numerik) {
  x <- data_clean[[var]]
  Q1  <- quantile(x, 0.25, na.rm = TRUE)
  Q3  <- quantile(x, 0.75, na.rm = TRUE)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  n_out <- sum(x < lower | x > upper, na.rm = TRUE)
  cat(var, ": Lower =", round(lower, 2),
      "| Upper =", round(upper, 2),
      "| Outlier =", n_out, "\n")
}

# Z-Score untuk verifikasi
cat("\n===== OUTLIER BERDASARKAN Z-SCORE (|z| > 3) =====\n")
for (var in numerik) {
  x   <- data_clean[[var]]
  z   <- (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
  n_z <- sum(abs(z) > 3, na.rm = TRUE)
  cat(var, ":", n_z, "outlier\n")
}


# ---- 5. VISUALISASI DATA ----

cat("\n===== MEMBUAT VISUALISASI =====\n")

# 5.1 Histogram PDRB per Kapita
p1 <- ggplot(data_clean, aes(x = pdrb_perkapita / 1e6)) +
  geom_histogram(bins = 40, fill = "#2563EB", color = "white", alpha = 0.85) +
  geom_vline(aes(xintercept = mean(pdrb_perkapita / 1e6)),
             color = "#DC2626", linetype = "dashed", linewidth = 1.2) +
  labs(title = "Distribusi PDRB Per Kapita Wilayah (2020–2024)",
       subtitle = "Garis merah = nilai mean",
       x = "PDRB Per Kapita (Juta Rupiah)",
       y = "Frekuensi") +
  theme_minimal(base_size = 12)

ggsave("../gambar/histogram_pdrb.png", p1, width = 9, height = 5, dpi = 150)
cat("  Visualisasi 1 (Histogram PDRB) tersimpan\n")

# 5.2 Boxplot Multi-variabel
df_long <- reshape2::melt(data_clean[, c("kemiskinan","pengangguran","ipm","akses_internet")],
                          variable.name = "Variabel", value.name = "Nilai")

p2 <- ggplot(df_long, aes(x = Variabel, y = Nilai, fill = Variabel)) +
  geom_boxplot(outlier.colour = "red", outlier.size = 1.5, alpha = 0.7) +
  scale_fill_manual(values = c("#DC2626","#EA580C","#16A34A","#2563EB")) +
  labs(title = "Boxplot Indikator Pembangunan Wilayah",
       subtitle = "Titik merah menunjukkan outlier berdasarkan IQR",
       x = "Indikator", y = "Nilai") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "none")

ggsave("../gambar/boxplot_indikator.png", p2, width = 10, height = 5, dpi = 150)
cat("  Visualisasi 2 (Boxplot Indikator) tersimpan\n")

# 5.3 Scatter Plot IPM vs Kemiskinan
p3 <- ggplot(data_clean, aes(x = ipm, y = kemiskinan, color = catatan_data)) +
  geom_point(alpha = 0.4, size = 1.5) +
  geom_smooth(method = "lm", se = TRUE, color = "#EA580C", linewidth = 1.2) +
  scale_color_manual(values = c("Normal" = "#2563EB", "Outlier" = "#DC2626",
                                "Missing Value" = "#6B7280")) +
  labs(title = "Hubungan IPM dan Tingkat Kemiskinan",
       subtitle = "Garis oranye = garis regresi linear",
       x = "Indeks Pembangunan Manusia (IPM)",
       y = "Tingkat Kemiskinan (%)",
       color = "Kategori Data") +
  theme_minimal(base_size = 12)

ggsave("../gambar/scatter_ipm_kemiskinan.png", p3, width = 8, height = 5, dpi = 150)
cat("  Visualisasi 3 (Scatter IPM vs Kemiskinan) tersimpan\n")

# 5.4 Bar Chart Kemiskinan per Provinsi
prov_mean <- data_clean %>%
  group_by(provinsi) %>%
  summarise(rata_kemiskinan = mean(kemiskinan, na.rm = TRUE)) %>%
  arrange(rata_kemiskinan)

p4 <- ggplot(prov_mean, aes(x = rata_kemiskinan,
                             y = reorder(provinsi, rata_kemiskinan),
                             fill = rata_kemiskinan > mean(data_clean$kemiskinan))) +
  geom_col(alpha = 0.85) +
  scale_fill_manual(values = c("FALSE" = "#2563EB", "TRUE" = "#DC2626"),
                    labels = c("Di bawah rata-rata", "Di atas rata-rata")) +
  geom_vline(xintercept = mean(data_clean$kemiskinan),
             color = "#EA580C", linetype = "dashed", linewidth = 1.2) +
  labs(title = "Rata-rata Tingkat Kemiskinan per Provinsi (2020–2024)",
       x = "Tingkat Kemiskinan (%)", y = "Provinsi",
       fill = "Status") +
  theme_minimal(base_size = 11)

ggsave("../gambar/bar_kemiskinan_provinsi.png", p4, width = 11, height = 5, dpi = 150)
cat("  Visualisasi 4 (Bar Kemiskinan Provinsi) tersimpan\n")

# 5.5 Heatmap Korelasi
corr_matrix <- cor(data_clean[, numerik], use = "complete.obs")
png("../gambar/heatmap_korelasi.png", width = 900, height = 800, res = 130)
corrplot::corrplot(corr_matrix,
                   method  = "color",
                   type    = "upper",
                   addCoef.col = "black",
                   tl.col  = "black",
                   tl.srt  = 45,
                   col     = colorRampPalette(c("#DC2626","white","#16A34A"))(200),
                   title   = "Heatmap Korelasi Antar Variabel Pembangunan",
                   mar     = c(0, 0, 2, 0),
                   number.cex = 0.75)
dev.off()
cat("  Visualisasi 5 (Heatmap Korelasi) tersimpan\n")

# 5.6 Tren PDRB per Tahun
tren_pdrb <- data_clean %>%
  group_by(tahun) %>%
  summarise(mean_pdrb = mean(pdrb_perkapita / 1e6, na.rm = TRUE))

p6 <- ggplot(tren_pdrb, aes(x = tahun, y = mean_pdrb)) +
  geom_line(color = "#2563EB", linewidth = 2) +
  geom_point(size = 4, color = "#2563EB") +
  geom_label(aes(label = round(mean_pdrb, 1)), vjust = -0.5, size = 3.5) +
  labs(title = "Tren Rata-rata PDRB Per Kapita (2020–2024)",
       x = "Tahun", y = "Rata-rata PDRB Per Kapita (Juta Rupiah)") +
  theme_minimal(base_size = 12)

ggsave("../gambar/line_tren_pdrb.png", p6, width = 9, height = 5, dpi = 150)
cat("  Visualisasi 6 (Line Tren PDRB) tersimpan\n")

cat("\nSemua visualisasi berhasil disimpan.\n")


# ---- 6. ANALISIS PROBABILITAS DAN DISTRIBUSI DATA ----

cat("\n===== UJI NORMALITAS (Shapiro-Wilk) =====\n")
cat("(Uji dilakukan pada sampel acak 200 observasi)\n\n")

set.seed(42)
for (var in numerik) {
  x      <- data_clean[[var]]
  samp   <- sample(x[!is.na(x)], min(200, sum(!is.na(x))))
  result <- shapiro.test(samp)
  normal <- if (result$p.value > 0.05) "BERDISTRIBUSI NORMAL" else "TIDAK NORMAL"
  cat(sprintf("%-20s W = %.4f, p-value = %.6f => %s\n",
              var, result$statistic, result$p.value, normal))
}

cat("\n===== PROBABILITAS SEDERHANA =====\n")

# P(kemiskinan > mean)
kem <- data_clean$kemiskinan
cat(sprintf("P(Kemiskinan > %.2f%% [mean]) = %.4f (%.2f%%)\n",
            mean(kem), mean(kem > mean(kem)), mean(kem > mean(kem)) * 100))

# P(IPM > 70)
ipm_v <- data_clean$ipm
cat(sprintf("P(IPM > 70)                  = %.4f (%.2f%%)\n",
            mean(ipm_v > 70), mean(ipm_v > 70) * 100))

# P(pengangguran > 10%)
peng <- data_clean$pengangguran
cat(sprintf("P(Pengangguran > 10%%)        = %.4f (%.2f%%)\n",
            mean(peng > 10), mean(peng > 10) * 100))

# P(akses_internet > 60%)
ai <- data_clean$akses_internet
cat(sprintf("P(Akses Internet > 60%%)      = %.4f (%.2f%%)\n",
            mean(ai > 60), mean(ai > 60) * 100))

# Menggunakan distribusi normal (pnorm)
cat("\n--- Perkiraan probabilitas menggunakan distribusi normal (pnorm) ---\n")
mu_kem  <- mean(kem)
sd_kem  <- sd(kem)
p_pnorm <- 1 - pnorm(mu_kem, mean = mu_kem, sd = sd_kem)
cat(sprintf("P(Kemiskinan > mean) via pnorm = %.4f\n", p_pnorm))

mu_ipm <- mean(ipm_v); sd_ipm <- sd(ipm_v)
p_ipm  <- 1 - pnorm(70, mean = mu_ipm, sd = sd_ipm)
cat(sprintf("P(IPM > 70) via pnorm         = %.4f (%.2f%%)\n", p_ipm, p_ipm * 100))

# Kuantil distribusi normal
cat("\n--- Kuantil distribusi kemiskinan ---\n")
cat("Nilai kemiskinan pada P90 (pnorm):", round(qnorm(0.90, mu_kem, sd_kem), 2), "\n")
cat("Nilai kemiskinan pada P10 (pnorm):", round(qnorm(0.10, mu_kem, sd_kem), 2), "\n")


# ---- 7. ANALISIS KORELASI ----

cat("\n===== MATRIKS KORELASI PEARSON =====\n")
corr_mat <- cor(data_clean[, numerik], use = "complete.obs")
print(round(corr_mat, 4))

cat("\n===== UJI SIGNIFIKANSI KORELASI =====\n")
pasangan <- list(
  c("ipm", "kemiskinan"),
  c("pdrb_perkapita", "kemiskinan"),
  c("akses_internet", "rata_lama_sekolah"),
  c("harapan_hidup", "ipm"),
  c("jalan_baik", "air_bersih")
)

for (pair in pasangan) {
  x_var <- data_clean[[pair[1]]]
  y_var <- data_clean[[pair[2]]]
  test  <- cor.test(x_var, y_var, method = "pearson")
  cat(sprintf("%-22s vs %-20s : r = %6.4f, p = %.6f %s\n",
              pair[1], pair[2],
              test$estimate, test$p.value,
              ifelse(test$p.value < 0.05, "(*signifikan*)", "")))
}


# ---- 8. RINGKASAN AKHIR ----
cat("\n===== RINGKASAN ANALISIS =====\n")
cat("Dataset       :", nrow(data), "observasi x", ncol(data), "variabel\n")
cat("Periode       : 2020–2024\n")
cat("Provinsi      :", length(unique(data$provinsi)), "provinsi\n")
cat("Missing value :", sum(is.na(data[, numerik])), "sel (ditangani: median imputation)\n")
cat("Outlier (flag): 20 baris berdasarkan kolom catatan_data\n")
cat("Distribusi    : Semua variabel TIDAK berdistribusi normal (Shapiro-Wilk)\n")
cat("Korelasi IPM–Kemiskinan: r =", round(corr_mat["ipm","kemiskinan"], 4), "\n")
cat("Skript selesai dieksekusi.\n")
