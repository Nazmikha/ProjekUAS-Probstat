# Proyek Akhir – Probabilitas dan Statistika
## Analisis Data Pembangunan Wilayah Indonesia

---

### Struktur Folder

```
probstat_NIM/
├── dataset/
│   └── pembangunan_wilayah_missing_outlier.csv   ← Dataset utama
├── script/
│   └── analisis_pembangunan.R                    ← Skrip R lengkap (semua analisis)
├── gambar/
│   ├── histogram_pdrb.png                        ← Visualisasi 1: Distribusi PDRB
│   ├── boxplot_indikator.png                     ← Visualisasi 2: Boxplot indikator
│   ├── scatter_ipm_kemiskinan.png                ← Visualisasi 3: Scatter IPM vs Kemiskinan
│   ├── bar_kemiskinan_provinsi.png               ← Visualisasi 4: Bar kemiskinan per provinsi
│   ├── heatmap_korelasi.png                      ← Visualisasi 5: Heatmap korelasi
│   ├── pie_missing_value.png                     ← Visualisasi 6: Proporsi missing value
│   └── line_tren_pdrb.png                        ← Visualisasi 7: Tren PDRB per tahun
├── dokumen/
│   ├── laporan_probstat.qmd                      ← Laporan utama (Quarto Markdown)
│   ├── referensi.bib                             ← File referensi BibTeX (12 sumber)
│   └── apa.csl                                   ← Format sitasi APA 7th edition
└── README.md                                     ← File ini
```

---

### Cara Menggunakan

#### Menjalankan Skrip R
1. Buka RStudio
2. Buka file `script/analisis_pembangunan.R`
3. Install package yang diperlukan (otomatis di baris awal skrip)
4. Jalankan skrip (Ctrl+Shift+Enter atau klik **Source**)

#### Merender Laporan QMD ke PDF
1. Buka file `dokumen/laporan_probstat.qmd` di RStudio
2. Pastikan Quarto sudah terinstall (`quarto --version`)
3. Jalankan: `quarto render dokumen/laporan_probstat.qmd`
4. File PDF akan muncul di folder `dokumen/`

> **Catatan**: Pastikan LaTeX (TinyTeX) sudah terinstall: `install.packages("tinytex"); tinytex::install_tinytex()`

---

### Packages R yang Dibutuhkan

```r
install.packages(c("ggplot2", "dplyr", "corrplot", "nortest", "reshape2", "moments", "knitr"))
```

---

### Dataset

**Nama file**: `pembangunan_wilayah_missing_outlier.csv`  
**Dimensi**: 2.500 observasi × 13 variabel  
**Cakupan**: 10 provinsi, periode 2020–2024  
**Karakteristik**: Mengandung *missing value* (149 sel) dan *outlier* (20 baris)

---

### Ringkasan Analisis

| Tahapan | Metode | Temuan Utama |
|---|---|---|
| Eksplorasi Data | `str()`, `summary()`, `head()` | 2.500 obs × 13 var, 10 provinsi, 2020–2024 |
| Statistika Deskriptif | Mean, Median, SD, Kuartil | PDRB tertinggi (SD=89,3 jt), Internet dispersi terluas |
| Missing Value | Median Imputation | 149 sel diimputasi pada 6 variabel |
| Outlier | IQR + Z-Score | PDRB, kemiskinan, pengangguran memiliki outlier paling banyak |
| Visualisasi | ggplot2 (7 grafik) | Histogram, Boxplot, Scatter, Bar, Heatmap, Pie, Line |
| Normalitas | Shapiro-Wilk | Semua variabel TIDAK berdistribusi normal |
| Probabilitas | Empiris + pnorm | ~50% wilayah di atas rata-rata kemiskinan, 49,58% IPM > 70 |
| Korelasi | Pearson + cor.test | Korelasi antar variabel relatif lemah dalam dataset panel ini |

---

### Referensi Utama

1. Tukey, J. W. (1977). *Exploratory Data Analysis*. Addison-Wesley.
2. Wickham, H. (2016). *ggplot2: Elegant Graphics for Data Analysis* (2nd ed.). Springer. https://doi.org/10.1007/978-3-319-24277-4
3. Field, A. (2018). *Discovering Statistics Using IBM SPSS Statistics* (5th ed.). SAGE.
4. Little, R. J. A., & Rubin, D. B. (2019). *Statistical Analysis with Missing Data* (3rd ed.). Wiley. https://doi.org/10.1002/9781119482260
5. BPS (2023). *Statistik Indonesia 2023*. https://www.bps.go.id/id/publication/2023/05/05/b477d4ab0cf99f8c7e52df62/statistik-indonesia-2023.html
